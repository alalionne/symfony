'use strict';

angular.module('campusApp')
    .directive('campusAppPager', function() {
        return {
            templateUrl: 'scripts/components/form/pager.html'
        };
    });
