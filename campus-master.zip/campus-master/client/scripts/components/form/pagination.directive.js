'use strict';

angular.module('campusApp')
    .directive('campusAppPagination', function() {
        return {
            templateUrl: 'scripts/components/form/pagination.html'
        };
    });
