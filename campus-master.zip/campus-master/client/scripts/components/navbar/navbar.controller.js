'use strict';

angular.module('campusApp')
    .controller('NavbarController', function () {
    });
