'use strict';

angular.module('campusApp')
    .controller('MainController', function () {
    });
