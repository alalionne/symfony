'use strict';

//not working
exports.getWindow = function() {
    return null;
};