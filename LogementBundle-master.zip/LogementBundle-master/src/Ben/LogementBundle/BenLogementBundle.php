<?php

namespace Ben\LogementBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BenLogementBundle extends Bundle
{
}
