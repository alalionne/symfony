<?php

namespace Ben\AssociationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BenAssociationBundle extends Bundle
{
}
