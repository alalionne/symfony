<?php
namespace App\Notification;

use App\Entity\Contact;

class ContactNotification 
{
    public function notify(Contact $contact){
        
    }
}